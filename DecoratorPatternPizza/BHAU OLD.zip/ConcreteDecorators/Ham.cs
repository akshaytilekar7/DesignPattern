﻿using DecoratorPatternPizza.Component;
using DecoratorPatternPizza.Decorator;

namespace DecoratorPatternPizza.ConcreteDecorators
{
    public class Ham : PizzaDecorator
    {
        public Ham(Pizza pizza) : base(pizza)
        {
            Description = this.GetType().Name;
        }

        public override string GetDescription()
        {
            return $"{Pizza.GetDescription()}, {this.GetType().Name}";
        }

        public override double CalculateCost()
        {
            return Pizza.CalculateCost() + 1.00;
        }
    }
}
