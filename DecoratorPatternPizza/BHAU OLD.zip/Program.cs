﻿using DecoratorPatternPizza.ConcreteComponents;
using DecoratorPatternPizza.ConcreteDecorators;
using System;

namespace DecoratorPatternPizza
{
    class Program
    {
        static void Main(string[] args)
        {
            //Pizza largePizza = new LargePizza();
            //largePizza = new Cheese(largePizza);
            //largePizza = new Ham(largePizza);

            var largePizza = new Ham(new Cheese(new LargePizza()));


            Console.WriteLine(largePizza.GetDescription());
            Console.WriteLine("{0:C2}", largePizza.CalculateCost());
            Console.ReadKey();
        }
    }
}
