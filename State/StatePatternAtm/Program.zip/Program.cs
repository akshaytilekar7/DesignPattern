﻿using StatePatternAtm.Context;
using StatePatternAtm.States;
using System;

namespace StatePatternAtm
{
    class Program
    {
        static void Main(string[] args)
        {
            Card card = new Card(new CardNotInsertedState());


            //card.EjectDebitCard();
            //card.EnterPin("1234");
            //card.WithdrawMoney(500);
            //Console.WriteLine("-------");

            card.InsertDebitCard();
            card.EnterPin("123334");
            card.WithdrawMoney(1000);
            card.EjectDebitCard();

            card.InsertDebitCard();
            card.WithdrawMoney(1001110);


            Console.ReadLine();
        }
    }
}
